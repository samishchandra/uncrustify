// Turning on sp_inside_braces=add fixes it, but also changes a lot of initializer code we don't want to touch (like x = {1}). May need special support, or perhaps there's a bug..
// long comment line(s), such as here, might be too long to produce a correct LOG-file such as
// with the use of option -L A
// in such a case, the output of the log will be cut.
